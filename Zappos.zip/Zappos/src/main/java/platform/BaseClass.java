package platform;

public class BaseClass {
	
	

}
